#include "review.h"
#include <iostream>
#include <string>
#include <vector>

using namespace std;


void ReadStdIn() {
    int integer_value;
    double double_value;
    string string_value;

    cin >> integer_value >> double_value >> string_value;

    cout << integer_value << endl;
    cout << double_value << endl;
    cout << string_value << endl;
}

int WriteOut(string output) {
    cout << output << endl;  
    return 1; 
}

int WriteOut(int output) {
    cout << output << endl;  
    return 2;  
}

int WriteOut(double output) {
    cout << output << endl; 
    return 3;  
}

void ReadStdIn2() {
    string input;
    int count = 0;

    while (true) {
        cin >> input;
        if (input == "q") {
            break;
        }
        count++;
    }

    cout << count << endl;
}


void ReadWrite() {
    string input;
    vector<string> inputs;

    while (true) {
        cin >> input;
        if (input == "q") {
            break;
        }
        inputs.push_back(input);
    }

    for (const auto& word : inputs) {
        cout << word << " ";
    }
    cout << endl;
}

vector<int> InitializeArray(int size) {
    vector<int> array(size, 0);
    return array;
}

void LoopThrough(double* data, int size) {
    for (int i = 0; i < size; ++i) {
        data[i] += 1.0;
    }
}

int Fibonacci(int a) {
    if (a == 0) {
        return 0;
    } else if (a == 1) {
        return 1;
    } else {
        return Fibonacci(a - 1) + Fibonacci(a - 2);
    }
}
