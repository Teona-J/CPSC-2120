#include "review.h"

int main() {
    //ReadStdIn();
	 ReadStdIn2();
    return 0;
}
