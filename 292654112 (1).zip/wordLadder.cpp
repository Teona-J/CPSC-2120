#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <string>
#include <algorithm>
using namespace std;

vector<string> V; //words from wordlist05.txt
						//Global variables for bfs distance, bfs predecessor, and neighboring nodes
						//Should be unordered_map type
unordered_map<string, int> bfs_distance;         
unordered_map<string, string> bfs_predecessor;    
unordered_map<string, vector<string>> neighbors;  

//check if two words differ by on letter
bool differByOne(const string &a, const string &b) {
	if (a.length() != b.length()) return false;
	int count = 0;
	for (size_t i = 0; i < a.length(); i++) {
		if (a[i] != b[i]) count++;
		if (count > 1) return false;
	}
	return count == 1;
}

// preprocess neighbors
void preprocessNeighbors() {
	for (const string &word : V) {
		for (const string &candidate : V) {
			if (differByOne(word, candidate)) {
				neighbors[word].push_back(candidate);
			}
		}
	}
}

// Breadth-First Search
void bfs(string source) {
	queue<string> q;
	q.push(source);
	bfs_distance[source] = 0;

	while (!q.empty()) {
		string current = q.front();
		q.pop();

		for (const string &neighbor : neighbors[current]) {
			if (bfs_distance.find(neighbor) == bfs_distance.end()) { 
				bfs_distance[neighbor] = bfs_distance[current] + 1;
				bfs_predecessor[neighbor] = current;
				q.push(neighbor);
			}
		}
	}
}


void wordLadder(string s, string t, int &steps, vector<string> &p) {
	V.clear();               
	neighbors.clear();       
	bfs_distance.clear();    
	bfs_predecessor.clear(); 

	// read in 
	ifstream file("wordlist05.txt");
	if (!file.is_open()) {
		cerr << "Error: Unable to open wordlist05.txt\n";
		steps = 0;
		return;
	}
	string word;
	while (file >> word) {
		V.push_back(word);
	}
	file.close();

	preprocessNeighbors();

	bfs(s);

	if (bfs_distance.find(t) == bfs_distance.end()) {
		steps = 0;
		return;
	}

	steps = bfs_distance[t];
	string current = t;
	while (current != s) {
		p.push_back(current);
		current = bfs_predecessor[current];
	}
	p.push_back(s);
	reverse(p.begin(), p.end());
}



/*int main(void)
  {
  int steps = 0;
  string s, t;
  vector<string> path;

  cout << "Source: ";
  cin >> s;

  cout << "Target: ";
  cin >> t;

  wordLadder(s, t, steps, path);

  if (steps == 0)
  {
  cout << "No path!\n";
  }
  else
  {
  cout << "Steps: " << steps << "\n\n";
  for (int i=0; i<path.size(); i++)
  {
  cout << path[i] << endl;
  }
  }
  return 0;
  }*/
