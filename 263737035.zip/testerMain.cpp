#include "review.h"

int main() {
    ReadStdIn();
    return 0;
}
