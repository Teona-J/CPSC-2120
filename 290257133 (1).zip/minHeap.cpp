/* Teona Johnson
	11/18/2024
	Cpsc 2120-002
	Min-Heap Implementation Using a Vector
*/

#include "minHeap.h"
#include <stdexcept>
#include <algorithm>


// Constructor to build a heap from a vector 
minHeap::minHeap(vector<int> data) {
    heap = data;
    for (int i = (heap.size() / 2) - 1; i >= 0; --i) {
        siftDown(i);
    }
}




// Insert 
void minHeap::insert(int value) {
    heap.push_back(value);
    siftUp(heap.size() - 1);
}

// Remove and return the min value
int minHeap::removeMin() {
    if (heap.empty()) {
        throw runtime_error("Heap is empty. Cannot remove minimum.");
    }
    int minValue = heap[0];
    heap[0] = heap.back();
    heap.pop_back();
    if (!heap.empty()) {
        siftDown(0);
    }
    return minValue;
}

// Sift-up
void minHeap::siftUp(int pos) {
    while (pos > 0) {
        int parent = (pos - 1) / 2;
        if (heap[pos] < heap[parent]) {
            swap(heap[pos], heap[parent]);
            pos = parent;
        } else {
            break;
        }
    }
}

// Sift-down
void minHeap::siftDown(int pos) {
    int n = heap.size();
    while (true) {
        int leftChild = 2 * pos + 1;
        int rightChild = 2 * pos + 2;
        int smallest = pos;

        if (leftChild < n && heap[leftChild] < heap[smallest]) {
            smallest = leftChild;
        }
        if (rightChild < n && heap[rightChild] < heap[smallest]) {
            smallest = rightChild;
        }
        if (smallest != pos) {
            swap(heap[pos], heap[smallest]);
            pos = smallest;
        } else {
            break;
        }
    }
}
