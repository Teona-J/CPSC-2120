#include "review.h"

int main() {
    //ReadStdIn();
	 //ReadStdIn2();
	   ReadWrite();
    return 0;
}
