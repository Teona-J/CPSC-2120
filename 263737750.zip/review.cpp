#include "review.h"
#include <iostream>
#include <string>

using namespace std;


void ReadStdIn() {
    int integer_value;
    double double_value;
    string string_value;

    cin >> integer_value >> double_value >> string_value;

    cout << integer_value << endl;
    cout << double_value << endl;
    cout << string_value << endl;
}

int WriteOut(string output) {
    cout << output << endl;  
    return 1; 
}

int WriteOut(int output) {
    cout << output << endl;  
    return 2;  
}

int WriteOut(double output) {
    cout << output << endl; 
    return 3;  
}
